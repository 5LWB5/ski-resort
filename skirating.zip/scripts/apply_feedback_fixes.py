"""Приведение итоговых CSV к правилам проверки проекта."""
from __future__ import annotations

from pathlib import Path
import numpy as np
import pandas as pd

ACCEPTED_FACT_STATUSES = {
    "source_checked", "official_page", "operator_page", "regional_tourism_official"
}

def numeric(value):
    if pd.isna(value):
        return np.nan
    text = str(value).strip().replace(",", ".")
    if text.startswith((">", "<")):
        return np.nan
    return pd.to_numeric(text, errors="coerce")

def minmax(series: pd.Series) -> pd.Series:
    values = pd.to_numeric(series, errors="coerce")
    low, high = values.min(), values.max()
    if pd.isna(low) or pd.isna(high) or high == low:
        return pd.Series(np.nan, index=series.index, dtype="float64")
    return (values - low) / (high - low) * 100

def enrich_manual_prices(root: Path) -> None:
    path = root / "data" / "processed" / "powerbi_daily_price_additions.csv"
    if not path.exists():
        return
    df = pd.read_csv(path, encoding="utf-8-sig")
    defaults = {
        "comparison_scenario": "взрослый; стандартный доступ; 1 день",
        "source_url": "user_provided_in_project_notes",
        "checked_at": "2026-10-24",
        "season": "сезон уточнить при публикации тарифа",
        "conditions": "Пользовательская цена за дневной тариф; специальные условия не указаны",
        "source_basis": "введено пользователем по материалам проекта",
    }
    for column, value in defaults.items():
        if column not in df.columns:
            df[column] = value
        else:
            df[column] = df[column].fillna(value).replace("", value)
    df["price_scope"] = "base_daily_adult"
    df.to_csv(path, index=False, encoding="utf-8-sig")

def recompute_comparable_prices(root: Path) -> pd.DataFrame:
    """Оставляет только взрослый/общий стандартный тариф на один день."""
    source_path = root / "data" / "reference" / "resort_prices.csv"
    additions_path = root / "data" / "processed" / "powerbi_daily_price_additions.csv"
    source = pd.read_csv(source_path, encoding="utf-8-sig")
    source = source[source["service_category"].eq("ski_pass")].copy()
    unit = source["pricing_unit"].fillna("").astype(str).str.lower().str.strip()
    category = source["visitor_category"].fillna("").astype(str).str.lower()
    special = source["conditions"].fillna("").astype(str).str.lower()
    one_day = unit.isin({"1 день", "день", "1 day", "day"})
    child_terms = ["детск", "child", "школь", "студен", "пенсион", "инвалид", "спортсмен"]
    special_terms = ["vip", "экспресс", "выходн", "будн", "комплект", "празднич", "новогод"]
    adult = ~category.apply(lambda x: any(term in x for term in child_terms))
    standard = ~special.apply(lambda x: any(term in x for term in special_terms))
    source["price_amount"] = pd.to_numeric(source["price_amount"], errors="coerce")
    source = source[source["currency"].eq("RUB") & one_day & adult & standard & source["price_amount"].gt(0)]
    daily = source.groupby("resort_id")["price_amount"].agg(
        avg_daily_ski_pass_price_rub="mean", median_daily_ski_pass_price_rub="median",
        min_daily_ski_pass_price_rub="min", max_daily_ski_pass_price_rub="max",
        price_tariff_count="count"
    )
    additions = pd.read_csv(additions_path, encoding="utf-8-sig").set_index("resort_id")
    manual = pd.to_numeric(additions["avg_daily_ski_pass_price_rub"], errors="coerce")
    for column in ["avg_daily_ski_pass_price_rub", "median_daily_ski_pass_price_rub",
                   "min_daily_ski_pass_price_rub", "max_daily_ski_pass_price_rub"]:
        additions[column] = manual
    additions["price_tariff_count"] = 1
    daily = daily.drop(index=additions.index, errors="ignore")
    daily = pd.concat([daily, additions[["avg_daily_ski_pass_price_rub",
                                         "median_daily_ski_pass_price_rub",
                                         "min_daily_ski_pass_price_rub",
                                         "max_daily_ski_pass_price_rub",
                                         "price_tariff_count"]]])
    return daily.reset_index()

def reconcile_master(root: Path) -> pd.DataFrame:
    master_path = root / "data" / "processed" / "resort_data_master.csv"
    facts_path = root / "data" / "reference" / "resort_source_facts.csv"
    master = pd.read_csv(master_path, encoding="utf-8-sig")
    facts = pd.read_csv(facts_path, encoding="utf-8-sig")
    facts = facts[facts["status"].isin(ACCEPTED_FACT_STATUSES)].copy()
    facts["numeric_value"] = facts["value"].map(numeric)
    fact_map = {"piste_total_km": "piste_total_km", "lift_count": "lift_count",
                "elevation_min_m": "elevation_min_m", "elevation_max_m": "elevation_max_m"}
    priorities = {"source_checked": 3, "official_page": 2, "operator_page": 1,
                  "regional_tourism_official": 1}
    for fact_name, target in fact_map.items():
        candidates = facts[(facts["fact_name"] == fact_name) & facts["numeric_value"].notna()].copy()
        candidates["_priority"] = candidates["status"].map(priorities).fillna(0)
        candidates = candidates.sort_values(["resort_id", "_priority", "checked_at"], ascending=[True, False, False])
        chosen = candidates.drop_duplicates("resort_id").set_index("resort_id")
        selected = master["resort_id"].map(chosen["numeric_value"])
        existing = pd.to_numeric(master[target], errors="coerce")
        master[f"{target}_selected"] = selected.combine_first(existing)
        master[f"{target}_selected_source"] = master["resort_id"].map(chosen["source_url"])
        master[f"{target}_selected_checked_at"] = master["resort_id"].map(chosen["checked_at"])
        master[f"{target}_selected_source"] = master[f"{target}_selected_source"].fillna("master_existing_value")
        master[f"{target}_selected_checked_at"] = master[f"{target}_selected_checked_at"].fillna(master.get("last_verified_at"))
    master["elevation_range_selected_m"] = (
        master["elevation_max_m_selected"] - master["elevation_min_m_selected"]
    ).where(
        master["elevation_max_m_selected"].notna() & master["elevation_min_m_selected"].notna(),
        pd.to_numeric(master["elevation_range_openskidata_m"], errors="coerce"),
    )
    master["selected_values_rule"] = "accepted source facts first; otherwise master; elevation range = max-min"
    master.to_csv(master_path, index=False, encoding="utf-8-sig")
    return master

def update_ranking(root: Path, master: pd.DataFrame, price_daily: pd.DataFrame) -> None:
    path = root / "data" / "processed" / "powerbi_monthly_ranking.csv"
    full_path = root / "data" / "processed" / "resort_monthly_ranking.csv"
    ranking = pd.read_csv(path, encoding="utf-8-sig")
    selected = master[["resort_id", "piste_total_km_selected", "lift_count_selected", "elevation_range_selected_m"]].drop_duplicates("resort_id")
    ranking = ranking.drop(columns=["piste_total_km_selected", "lift_count_selected", "elevation_range_selected_m"], errors="ignore").merge(selected, on="resort_id", how="left", validate="many_to_one")
    ranking = ranking.drop(columns=[c for c in price_daily.columns if c != "resort_id" and c in ranking.columns], errors="ignore").merge(price_daily, on="resort_id", how="left", validate="many_to_one")
    ranking["piste_length_score"] = minmax(ranking["piste_total_km_selected"])
    ranking["lift_count_score"] = minmax(ranking["lift_count_selected"])
    ranking["elevation_range_score"] = minmax(ranking["elevation_range_selected_m"])
    infra = ["piste_length_score", "lift_count_score", "elevation_range_score"]
    ranking["infrastructure_components_available"] = ranking[infra].notna().sum(axis=1)
    ranking["infrastructure_components_pct"] = ranking["infrastructure_components_available"] / 3 * 100
    ranking["infrastructure_data_status"] = np.where(ranking["infrastructure_components_available"].eq(3), "полные данные", "неполные данные")
    ranking["infrastructure_score"] = ranking[infra].mean(axis=1, skipna=True)
    price_min, price_max = ranking["avg_daily_ski_pass_price_rub"].min(), ranking["avg_daily_ski_pass_price_rub"].max()
    ranking["price_score"] = 100 * (price_max - ranking["avg_daily_ski_pass_price_rub"]) / (price_max - price_min)
    ranking["price_comparison_scenario"] = "взрослый; стандартный доступ; 1 день"
    criteria = ["weather_score", "infrastructure_score", "price_score"]
    ranking["criteria_used_count"] = ranking[criteria].notna().sum(axis=1)
    ranking["overall_score"] = ranking[criteria].mean(axis=1, skipna=True)
    ranking["comparison_eligible"] = ranking["is_ski_season"].fillna(False).astype(bool)
    ranking["eligibility_basis"] = "seasonal climatology only; current opening not verified"
    ranking["eligibility_note"] = np.where(ranking["comparison_eligible"], "сезонный месяц", "вне заданного сезона")
    ranking["overall_rank"] = ranking.groupby("month_number")["overall_score"].rank(method="min", ascending=False).astype("Int64")
    ranking["weather_rank"] = ranking.groupby("month_number")["weather_score"].rank(method="min", ascending=False).astype("Int64")
    ranking.to_csv(path, index=False, encoding="utf-8-sig")
    if full_path.exists():
        full = pd.read_csv(full_path, encoding="utf-8-sig")
        replace_cols = [c for c in ranking.columns if c not in {"resort_id", "month_number"}]
        full = full.drop(columns=[c for c in replace_cols if c in full.columns], errors="ignore")
        full = full.merge(
            ranking[["resort_id", "month_number", *replace_cols]],
            on=["resort_id", "month_number"], how="left", validate="one_to_one"
        )
        full.to_csv(full_path, index=False, encoding="utf-8-sig")

def update_resort_exports(root: Path, master: pd.DataFrame) -> None:
    selected = master[["resort_id", "piste_total_km_selected", "lift_count_selected",
                       "elevation_min_m_selected", "elevation_max_m_selected",
                       "elevation_range_selected_m"]].drop_duplicates("resort_id")
    for name in ["powerbi_resorts.csv", "powerbi_resorts_with_transfers.csv"]:
        path = root / "data" / "processed" / name
        if not path.exists():
            continue
        df = pd.read_csv(path, encoding="utf-8-sig")
        df = df.drop(columns=[c for c in selected.columns if c != "resort_id"], errors="ignore")
        df = df.merge(selected, on="resort_id", how="left", validate="one_to_one")
        df["piste_total_km"] = df["piste_total_km_selected"]
        df["lift_count"] = df["lift_count_selected"]
        df["elevation_min_m"] = df["elevation_min_m_selected"]
        df["elevation_max_m"] = df["elevation_max_m_selected"]
        df["elevation_range_openskidata_m"] = df["elevation_range_selected_m"]
        df = df.drop(columns=[c for c in selected.columns if c != "resort_id"])
        df.to_csv(path, index=False, encoding="utf-8-sig")

def normalize_airports(root: Path) -> None:
    path = root / "data" / "processed" / "powerbi_resorts_with_transfers.csv"
    if not path.exists():
        return
    df = pd.read_csv(path, encoding="utf-8-sig")
    df["airport_scheduled_service_raw"] = df["airport_scheduled_service"]
    status = df["airport_service_verification_status"].fillna("").astype(str)
    raw = df["airport_scheduled_service"].fillna("").astype(str).str.lower()
    df["airport_availability_status"] = np.select([status.str.startswith("verified_active"), raw.eq("yes")], ["verified_active", "scheduled_flag_yes"], default="not_verified")
    df["airport_recommendation_eligible"] = df["airport_availability_status"].eq("verified_active") | raw.eq("yes")
    df.to_csv(path, index=False, encoding="utf-8-sig")

def normalize_transfer_units(root: Path) -> None:
    """Добавляет читаемую подпись, не меняя исходное fare_unit."""
    path = root / "data" / "processed" / "powerbi_transfer_options.csv"
    if not path.exists():
        return
    df = pd.read_csv(path, encoding="utf-8-sig")
    labels = {
        "from_per_vehicle_one_way": "От, за автомобиль в одну сторону",
        "from_per_vehicle": "От, за автомобиль",
        "from_per_person_one_way": "От, с человека в одну сторону",
        "per_vehicle_one_way": "За автомобиль в одну сторону",
        "per_vehicle": "За автомобиль",
        "per_person_one_way": "С человека в одну сторону",
        "per_person": "С человека",
        "per_person_round_trip": "С человека туда и обратно",
        "not_published": "Цена не опубликована",
        "not_specified": "Единица цены не указана",
    }
    df["fare_unit_label"] = df["fare_unit"].map(labels).fillna(df["fare_unit"])
    df.to_csv(path, index=False, encoding="utf-8-sig")

def main() -> None:
    root = Path(__file__).resolve().parents[1]
    enrich_manual_prices(root)
    master = reconcile_master(root)
    price_daily = recompute_comparable_prices(root)
    update_ranking(root, master, price_daily)
    update_resort_exports(root, master)
    normalize_airports(root)
    normalize_transfer_units(root)
    print("Feedback fixes applied")

if __name__ == "__main__":
    main()
