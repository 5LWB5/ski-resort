"""Финализация шестикритериального персонального рейтинга."""
from pathlib import Path
import numpy as np
import pandas as pd

CRITERIA = [
    ("weather_score", "Погода", "Погода", "Температурный и общий погодный балл"),
    ("snow_score", "Снег", "Снег", "Объединённый балл снегопада и снежных дней"),
    ("piste_length_score", "Длина трасс", "Трассы", "Общая длина трасс"),
    ("lift_count_score", "Подъёмники", "Инфраструктура", "Количество подъёмников"),
    ("elevation_range_score", "Перепад высот", "Инфраструктура", "Диапазон высот"),
    ("price_score", "Цена дневного ски-пасса", "Стоимость", "Сопоставимый дневной тариф"),
]

def calculate(table, priorities):
    keys = [x[0] for x in CRITERIA]
    values = table[keys].apply(pd.to_numeric, errors="coerce")
    weights = pd.Series(priorities, dtype="float64")
    result = table.copy()
    result["available_criteria_count"] = values.notna().sum(axis=1)
    result["available_criteria_pct"] = result["available_criteria_count"] / len(keys) * 100
    result["missing_criteria"] = values.isna().apply(lambda row: ", ".join(row.index[row].tolist()), axis=1)
    if weights.sum() <= 0:
        result["personal_score"] = np.nan
        result["criteria_coverage_pct"] = 0.0
        result["personal_rank"] = pd.Series(pd.array([pd.NA] * len(result), dtype="Int64"))
        result["rating_status"] = "Выбери хотя бы один критерий"
        return result
    normalized = weights / weights.sum()
    available_weight = values.notna().mul(normalized, axis=1).sum(axis=1)
    weighted = values.fillna(0).mul(normalized, axis=1).sum(axis=1)
    result["personal_score"] = (weighted / available_weight).where(available_weight > 0)
    result["criteria_coverage_pct"] = available_weight * 100
    result["personal_rank"] = result.groupby("month_number")["personal_score"].rank(ascending=False, method="min").astype("Int64")
    result["rating_status"] = np.where(result["personal_score"].notna(), "Расчёт выполнен", "Нет доступных критериев")
    return result.sort_values(["month_number", "personal_rank", "resort_name"], na_position="last")

def main():
    root = Path(__file__).resolve().parents[1]
    out = root / "notebooks" / "powerbi_personal_rating"
    components = pd.read_csv(out / "personal_rating_components.csv", encoding="utf-8-sig")
    if "snow_score" not in components:
        components["snow_score"] = (components["snowfall_score"] * 0.5 + components["snowy_days_score"] * 0.5)
    catalog = pd.DataFrame(CRITERIA, columns=["criterion_key", "criterion_name_ru", "criterion_group", "description"])
    template = catalog[["criterion_key", "criterion_name_ru", "criterion_group"]].copy()
    template["priority_value"] = 1
    equal = {key: 1 for key, *_ in CRITERIA}
    price = equal.copy(); price["price_score"] = 5
    equal_rating = calculate(components, equal)
    price_rating = calculate(components, price)
    # Сохраняем только финальные компоненты и метаданные полноты по тем же шести ключам.
    keep = ["resort_id", "resort_name", "month_number", "month_name_ru"] + [x[0] for x in CRITERIA]
    components = equal_rating[keep + ["available_criteria_count", "available_criteria_pct", "missing_criteria"]].copy()
    comparison = equal_rating[["resort_id", "resort_name", "month_number", "month_name_ru", "personal_score", "personal_rank"]].rename(columns={"personal_score": "score_equal", "personal_rank": "rank_equal"})
    comparison = comparison.merge(price_rating[["resort_id", "month_number", "personal_score", "personal_rank"]].rename(columns={"personal_score": "score_price_priority", "personal_rank": "rank_price_priority"}), on=["resort_id", "month_number"], validate="one_to_one")
    components.to_csv(out / "personal_rating_components.csv", index=False, encoding="utf-8-sig")
    catalog.to_csv(out / "criteria_catalog.csv", index=False, encoding="utf-8-sig")
    template.to_csv(out / "priority_template.csv", index=False, encoding="utf-8-sig")
    comparison.to_csv(out / "scenario_comparison_check.csv", index=False, encoding="utf-8-sig")
    assert len(catalog) == len(template) == 6
    assert len(comparison) == len(components) == 210
    assert not components.duplicated(["resort_id", "month_number"]).any()
    print("Personal rating finalized: 6 criteria, 210 rows")

if __name__ == "__main__":
    main()
