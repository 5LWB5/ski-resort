"""Запуск подготовки данных проекта одной командой.

Примеры:
    python run_pipeline.py
    python run_pipeline.py --refresh-forecast --forecast-days 16

По умолчанию выполняется чистовая тетрадка и обновляются CSV-файлы для
Power BI. Прогноз Open-Meteo обновляется только по флагу
``--refresh-forecast``. Он сохраняется отдельно от климатологии и пока не
подменяет месячный климатологический рейтинг.
"""
from __future__ import annotations

import argparse
import csv
import subprocess
import sys
from datetime import datetime
from pathlib import Path


NOTEBOOK_NAME = "Подготовка_данных_курортов.ipynb"
EXPECTED_OUTPUTS = {
    "data/processed/powerbi_monthly_ranking.csv": 210,
    "data/processed/powerbi_resorts.csv": 30,
    "data/processed/powerbi_resorts_with_transfers.csv": 30,
    "data/processed/powerbi_transfer_options.csv": 43,
    "data/processed/powerbi_airport_routes_top3.csv": 90,
}


def find_project_dir(explicit: str | None = None) -> Path:
    if explicit:
        root = Path(explicit).expanduser().resolve()
        if (root / "data" / "processed").is_dir():
            return root
        raise FileNotFoundError(f"В указанной папке нет data/processed: {root}")

    root = Path(__file__).resolve().parent
    if (root / "data" / "processed").is_dir():
        return root
    raise FileNotFoundError("Не найден корень проекта рядом с run_pipeline.py")


def refresh_forecast(project_dir: Path, days: int) -> None:
    collector = project_dir / "scripts" / "collect_weather_forecast.py"
    if not collector.exists():
        raise FileNotFoundError(f"Не найден сборщик прогноза: {collector}")
    command = [sys.executable, str(collector), "--days", str(days)]
    subprocess.run(command, cwd=project_dir, check=True)


def execute_notebook(project_dir: Path, notebook_path: Path) -> Path:
    try:
        import nbformat
        from nbclient import NotebookClient
    except ImportError as exc:
        raise RuntimeError(
            "Для запуска тетрадки установите зависимости из requirements.txt: "
            "pip install -r requirements.txt"
        ) from exc

    notebook = nbformat.read(notebook_path, as_version=4)
    client = NotebookClient(
        notebook,
        timeout=1800,
        kernel_name="python3",
        resources={"metadata": {"path": str(project_dir)}},
        allow_errors=False,
    )
    client.execute()

    runs_dir = project_dir / "notebooks" / "runs"
    runs_dir.mkdir(exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    executed_path = runs_dir / f"{notebook_path.stem}_executed_{stamp}.ipynb"
    nbformat.write(notebook, executed_path)
    return executed_path


def validate_outputs(project_dir: Path) -> None:
    for relative_name, expected_rows in EXPECTED_OUTPUTS.items():
        path = project_dir / relative_name
        if not path.exists():
            raise FileNotFoundError(f"Не создан ожидаемый файл: {path}")
        with path.open(encoding="utf-8-sig", newline="") as stream:
            rows = sum(1 for _ in csv.DictReader(stream))
        if rows != expected_rows:
            raise RuntimeError(
                f"Неверное число строк в {relative_name}: {rows}, ожидалось {expected_rows}"
            )
        print(f"OK {relative_name}: {rows} строк")

def apply_feedback_fixes(project_dir: Path) -> None:
    fixer = project_dir / "scripts" / "apply_feedback_fixes.py"
    if not fixer.exists():
        raise FileNotFoundError(f"Не найден этап проверки данных: {fixer}")
    subprocess.run([sys.executable, str(fixer)], cwd=project_dir, check=True)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--project-dir", help="Путь к корню проекта")
    parser.add_argument(
        "--notebook",
        default=NOTEBOOK_NAME,
        help="Имя тетрадки в папке notebooks",
    )
    parser.add_argument(
        "--refresh-forecast",
        action="store_true",
        help="Перед расчетом запросить прогноз Open-Meteo",
    )
    parser.add_argument(
        "--forecast-days",
        type=int,
        default=16,
        choices=range(1, 17),
        help="Горизонт прогноза Open-Meteo: от 1 до 16 дней",
    )
    args = parser.parse_args()

    project_dir = find_project_dir(args.project_dir)
    notebook_path = project_dir / "notebooks" / args.notebook
    if not notebook_path.exists():
        raise FileNotFoundError(f"Не найдена тетрадка: {notebook_path}")

    print(f"Проект: {project_dir}")
    if args.refresh_forecast:
        print(f"Обновление прогноза на {args.forecast_days} дней...")
        refresh_forecast(project_dir, args.forecast_days)

    print(f"Запуск: {notebook_path.name}")
    executed_path = execute_notebook(project_dir, notebook_path)
    print("Применение правил сопоставимости и полноты данных...")
    apply_feedback_fixes(project_dir)
    personal_script = project_dir / "scripts" / "finalize_personal_rating.py"
    print("Синхронизация шестикритериального персонального рейтинга...")
    subprocess.run([sys.executable, str(personal_script)], cwd=project_dir, check=True)
    validate_outputs(project_dir)
    print(f"Выполненная копия тетрадки: {executed_path}")
    print("Готово. В Power BI выполните Обновить.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
