"""Collect approximate resort/locality coordinate candidates from Open-Meteo.

Coordinates are candidates for general resort location, not exact ski slopes.
Raw API responses are cached; review before using as a finalized location.
"""
import csv
import json
import time
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urlencode
from urllib.request import Request, urlopen

ROOT = Path(__file__).resolve().parents[1]
ROSTER = ROOT / "data/reference/resort_roster.csv"
RAW = ROOT / "data/raw/geocoding_candidates"
SUMMARY = ROOT / "data/reference/geocoding_candidates_summary.csv"
ENDPOINT = "https://geocoding-api.open-meteo.com/v1/search"


def main():
    with ROSTER.open(encoding="utf-8-sig", newline="") as f:
        resorts = [r for r in csv.DictReader(f) if r.get("project_status", "active") == "active"]
    RAW.mkdir(parents=True, exist_ok=True)
    summary = []
    for i, resort in enumerate(resorts):
        params = {"name": resort["name_ru"], "count": 10, "language": "ru", "countryCode": "RU", "format": "json"}
        url = ENDPOINT + "?" + urlencode(params)
        request = Request(url, headers={"User-Agent": "TravelDesignerResortRanking/0.1 (research prototype)"})
        try:
            with urlopen(request, timeout=30) as response:
                status, data = response.status, json.load(response)
            results = data.get("results", [])
            payload = {
                "source": "Open-Meteo Geocoding API", "resort_id": resort["resort_id"],
                "roster_name": resort["name_ru"], "roster_region": resort["region_from_brief"],
                "retrieved_at_utc": datetime.now(timezone.utc).isoformat(), "request_url": url,
                "http_status": status, "results": results,
                "review_status": "candidate_only_approximate_location_not_verified",
            }
            best = results[0] if results else {}
            print(f"{resort['resort_id']} {resort['name_ru']}: {len(results)} candidate(s)" +
                  (f"; first={best.get('name')} / {best.get('admin1')} / {best.get('country')}" if results else ""))
            row = {"resort_id": resort["resort_id"], "resort_name": resort["name_ru"],
                   "roster_region": resort["region_from_brief"], "candidate_count": len(results),
                   "candidate_name": best.get("name", ""), "candidate_admin1": best.get("admin1", ""),
                   "candidate_country": best.get("country", ""), "latitude": best.get("latitude", ""),
                   "longitude": best.get("longitude", ""), "elevation_m": best.get("elevation", ""),
                   "status": "review_candidate" if results else "no_match",
                   "raw_response_file": f"data/raw/geocoding_candidates/{resort['resort_id']}_open_meteo_geocoding.json"}
        except Exception as exc:
            payload = {"source": "Open-Meteo Geocoding API", "resort_id": resort["resort_id"],
                       "roster_name": resort["name_ru"], "retrieved_at_utc": datetime.now(timezone.utc).isoformat(),
                       "request_url": url, "error": str(exc), "results": [], "review_status": "request_failed"}
            row = {"resort_id": resort["resort_id"], "resort_name": resort["name_ru"],
                   "roster_region": resort["region_from_brief"], "candidate_count": 0,
                   "status": "request_failed",
                   "raw_response_file": f"data/raw/geocoding_candidates/{resort['resort_id']}_open_meteo_geocoding.json"}
            print(f"{resort['resort_id']} {resort['name_ru']}: ERROR {exc}")
        (RAW / f"{resort['resort_id']}_open_meteo_geocoding.json").write_text(
            json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
        summary.append(row)
        if i < len(resorts) - 1:
            time.sleep(1)
    fields = ["resort_id", "resort_name", "roster_region", "candidate_count", "candidate_name",
              "candidate_admin1", "candidate_country", "latitude", "longitude", "elevation_m", "status", "raw_response_file"]
    with SUMMARY.open("w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        writer.writerows(summary)
    print(f"Saved {len(summary)} rows to {SUMMARY}")


if __name__ == "__main__":
    main()

