"""Small Open-Meteo API exercise: geocode a place, then request its forecast.

This is an API-learning example only. A geocoder usually returns a settlement
coordinate, not the exact centre/elevation of a ski resort. Verify resort
coordinates before using weather responses in the ranking.
"""

from __future__ import annotations

import argparse
import json
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urlencode
from urllib.request import Request, urlopen


PROJECT_DIR = Path(__file__).resolve().parents[1]
OUTPUT_DIR = PROJECT_DIR / "data" / "learning_examples"
USER_AGENT = "TravelDesignerOpenDataLearning/0.1"


def get_json(url: str) -> dict:
    request = Request(url, headers={"User-Agent": USER_AGENT})
    with urlopen(request, timeout=30) as response:
        return json.load(response)


def make_url(base: str, params: dict[str, str]) -> str:
    return f"{base}?{urlencode(params)}"


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--name",
        default="Кировск, Мурманская область",
        help="Place to search for; use a country/region qualifier for clearer results.",
    )
    args = parser.parse_args()

    geocoding_url = make_url(
        "https://geocoding-api.open-meteo.com/v1/search",
        {"name": args.name, "countryCode": "RU", "language": "ru", "count": "5"},
    )
    geocoding = get_json(geocoding_url)
    results = geocoding.get("results", [])
    if not results:
        raise SystemExit(f"No place found for: {args.name}")

    # For this exercise, choose the first geocoding match. Inspect it before use.
    place = results[0]
    forecast_url = make_url(
        "https://api.open-meteo.com/v1/forecast",
        {
            "latitude": str(place["latitude"]),
            "longitude": str(place["longitude"]),
            "daily": ",".join(
                [
                    "temperature_2m_max",
                    "temperature_2m_min",
                    "snowfall_sum",
                    "precipitation_sum",
                    "wind_speed_10m_max",
                    "weather_code",
                ]
            ),
            "forecast_days": "7",
            "timezone": place.get("timezone", "auto"),
        },
    )
    forecast = get_json(forecast_url)

    payload = {
        "purpose": "API learning example; not validated resort data",
        "source": "Open-Meteo Geocoding API and Forecast API",
        "retrieved_at_utc": datetime.now(timezone.utc).isoformat(),
        "geocoding_request_url": geocoding_url,
        "geocoding_response": geocoding,
        "forecast_request_url": forecast_url,
        "forecast_response": forecast,
        "warning": (
            "Geocoding result may represent a town centre, not the ski-resort "
            "slopes. Verify coordinates and elevation before ranking resorts."
        ),
    }

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    output_path = OUTPUT_DIR / "open_meteo_api_learning_example.json"
    output_path.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8"
    )

    print(f"Matched place: {place['name']}, {place.get('admin1', '')}, {place['country']}")
    print(f"Coordinates: {place['latitude']}, {place['longitude']}; elevation: {place.get('elevation')} m")
    print(f"Forecast timezone: {forecast.get('timezone')}")
    print(f"Forecast days returned: {len(forecast.get('daily', {}).get('time', []))}")
    print(f"Saved both raw responses and request URLs to: {output_path}")
    print("Reminder: these are place-centre coordinates, not verified resort coordinates.")


if __name__ == "__main__":
    main()
