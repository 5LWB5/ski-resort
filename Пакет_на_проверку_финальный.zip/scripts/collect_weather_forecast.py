"""Fetch a multi-location Open-Meteo forecast for active resorts.

Uses the fixed coordinates in the collection table. The free endpoint is for
non-commercial prototyping only; confirm a commercial licence/provider before
using the data in a production service.
"""
from __future__ import annotations

import argparse
import csv
import json
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urlencode
from urllib.request import Request, urlopen


PROJECT_DIR = Path(__file__).resolve().parents[1]
RESORTS_PATH = PROJECT_DIR / "data" / "reference" / "resort_data_collection_template.csv"
RAW_DIR = PROJECT_DIR / "data" / "raw" / "weather_forecasts"
PROCESSED_DIR = PROJECT_DIR / "data" / "processed"
ENDPOINT = "https://api.open-meteo.com/v1/forecast"
USER_AGENT = "TravelDesignerResortRanking/0.1 (prototype)"
DAILY_VARIABLES = [
    "temperature_2m_max",
    "temperature_2m_min",
    "snowfall_sum",
    "precipitation_sum",
    "wind_speed_10m_max",
    "weather_code",
]


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--days", type=int, default=16, choices=range(1, 17),
                        help="Forecast horizon in days (Open-Meteo supports up to 16).")
    args = parser.parse_args()

    with RESORTS_PATH.open(encoding="utf-8-sig", newline="") as stream:
        resorts = [row for row in csv.DictReader(stream)
                   if row.get("project_status", "active") == "active"]
    missing = [row["resort_name"] for row in resorts
               if not row.get("latitude") or not row.get("longitude")]
    if missing:
        raise SystemExit("Active resorts are missing coordinates: " + ", ".join(missing))
    if not resorts:
        raise SystemExit("No active resorts found in the coordinate table.")

    params = {
        "latitude": ",".join(row["latitude"] for row in resorts),
        "longitude": ",".join(row["longitude"] for row in resorts),
        "daily": ",".join(DAILY_VARIABLES),
        "forecast_days": str(args.days),
        "timezone": "auto",
        "temperature_unit": "celsius",
        "wind_speed_unit": "kmh",
        "precipitation_unit": "mm",
    }
    request_url = ENDPOINT + "?" + urlencode(params)
    request = Request(request_url, headers={"User-Agent": USER_AGENT})
    with urlopen(request, timeout=90) as response:
        http_status = response.status
        api_response = json.load(response)

    # The API returns one JSON object per requested coordinate when locations
    # are passed as comma-separated latitude/longitude lists.
    responses = api_response if isinstance(api_response, list) else [api_response]
    if len(responses) != len(resorts):
        raise SystemExit(
            f"Expected {len(resorts)} location responses, got {len(responses)}. "
            "Raw API response was not saved because resort-to-response mapping is ambiguous."
        )

    retrieved_at = datetime.now(timezone.utc).isoformat()
    snapshot = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    RAW_DIR.mkdir(parents=True, exist_ok=True)
    PROCESSED_DIR.mkdir(parents=True, exist_ok=True)
    raw_path = RAW_DIR / f"open_meteo_forecast_{snapshot}.json"
    raw_payload = {
        "source": "Open-Meteo Forecast API",
        "retrieved_at_utc": retrieved_at,
        "http_status": http_status,
        "request_url": request_url,
        "resort_order": [
            {"resort_id": row["resort_id"], "resort_name": row["resort_name"],
             "input_latitude": row["latitude"], "input_longitude": row["longitude"]}
            for row in resorts
        ],
        "daily_variables": DAILY_VARIABLES,
        "response": api_response,
    }
    raw_path.write_text(json.dumps(raw_payload, ensure_ascii=False, indent=2), encoding="utf-8")

    fields = [
        "resort_id", "resort_name", "latitude_input", "longitude_input",
        "latitude_api_grid", "longitude_api_grid", "elevation_api_m",
        "timezone", "forecast_date", *DAILY_VARIABLES,
        "temperature_unit", "snowfall_unit", "precipitation_unit", "wind_speed_unit",
        "source", "retrieved_at_utc", "raw_response_file",
    ]
    csv_path = PROCESSED_DIR / "weather_forecast_daily.csv"
    with csv_path.open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        for resort, forecast in zip(resorts, responses):
            daily = forecast.get("daily", {})
            units = forecast.get("daily_units", {})
            dates = daily.get("time", [])
            for index, date in enumerate(dates):
                row = {
                    "resort_id": resort["resort_id"], "resort_name": resort["resort_name"],
                    "latitude_input": resort["latitude"], "longitude_input": resort["longitude"],
                    "latitude_api_grid": forecast.get("latitude"),
                    "longitude_api_grid": forecast.get("longitude"),
                    "elevation_api_m": forecast.get("elevation"), "timezone": forecast.get("timezone"),
                    "forecast_date": date, "temperature_unit": units.get("temperature_2m_max", ""),
                    "snowfall_unit": units.get("snowfall_sum", ""),
                    "precipitation_unit": units.get("precipitation_sum", ""),
                    "wind_speed_unit": units.get("wind_speed_10m_max", ""),
                    "source": "Open-Meteo Forecast API", "retrieved_at_utc": retrieved_at,
                    "raw_response_file": str(raw_path.relative_to(PROJECT_DIR)),
                }
                for variable in DAILY_VARIABLES:
                    values = daily.get(variable, [])
                    row[variable] = values[index] if index < len(values) else ""
                writer.writerow(row)

    print(f"Resorts requested: {len(resorts)}")
    print(f"Days requested: {args.days}")
    print(f"HTTP status: {http_status}")
    print(f"Forecast rows written: {len(resorts) * len(responses[0].get('daily', {}).get('time', []))}")
    print(f"Raw API response: {raw_path}")
    print(f"Normalized daily data: {csv_path}")
    print("Forecast horizon only; dates beyond it need a separate approximate climate baseline.")


if __name__ == "__main__":
    main()
