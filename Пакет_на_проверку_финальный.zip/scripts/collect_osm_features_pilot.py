"""Query OSM ski pistes and lifts around the R001 coordinate candidate.

The centre comes from a Nominatim search candidate and is approximate. The
result is an API-learning/source-coverage pilot, not final resort data.
"""

from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urlencode
from urllib.request import Request, urlopen


PROJECT_DIR = Path(__file__).resolve().parents[1]
CANDIDATE_PATH = (
    PROJECT_DIR
    / "data"
    / "raw"
    / "coordinate_candidates"
    / "R001_nominatim_candidates.json"
)
OUTPUT_DIR = PROJECT_DIR / "data" / "raw" / "osm_pilots"
ENDPOINT = "https://overpass-api.de/api/interpreter"
USER_AGENT = "TravelDesignerResortRanking/0.1 (research prototype)"
RADIUS_METERS = 6000


def main() -> None:
    candidate_data = json.loads(CANDIDATE_PATH.read_text(encoding="utf-8"))
    candidates = candidate_data.get("results", [])
    if not candidates:
        raise SystemExit("No geocoding candidates found. Run the coordinate pilot first.")

    # Use the first candidate only to test OSM coverage. Do not accept it as
    # the resort's final location without map/source review.
    candidate = candidates[0]
    lat, lon = float(candidate["lat"]), float(candidate["lon"])
    query = f"""[out:json][timeout:45];
(
  way(around:{RADIUS_METERS},{lat},{lon})[\"piste:type\"];
  relation(around:{RADIUS_METERS},{lat},{lon})[\"route\"=\"piste\"];
  way(around:{RADIUS_METERS},{lat},{lon})[\"aerialway\"];
);
out center tags;"""

    body = urlencode({"data": query}).encode("utf-8")
    request = Request(
        ENDPOINT,
        data=body,
        headers={
            "User-Agent": USER_AGENT,
            "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
        },
        method="POST",
    )
    with urlopen(request, timeout=60) as response:
        status = response.status
        osm = json.load(response)

    elements = osm.get("elements", [])
    summary: dict[str, int] = {}
    for element in elements:
        tags = element.get("tags", {})
        category = tags.get("piste:type") or f"aerialway:{tags.get('aerialway', 'unknown')}"
        summary[category] = summary.get(category, 0) + 1

    payload = {
        "source": "OpenStreetMap Overpass API",
        "resort_id": "R001",
        "resort_name": "Роза Хутор",
        "search_center_source": "first Nominatim candidate; not verified as resort center",
        "search_center": {"latitude": lat, "longitude": lon},
        "radius_meters": RADIUS_METERS,
        "retrieved_at_utc": datetime.now(timezone.utc).isoformat(),
        "endpoint": ENDPOINT,
        "http_status": status,
        "overpass_query": query,
        "feature_summary": summary,
        "response": osm,
        "review_status": "coverage_pilot_only_not_final_metrics",
    }

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    output_path = OUTPUT_DIR / "R001_overpass_pilot.json"
    output_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")

    print(f"Resort: {payload['resort_name']} (R001)")
    print(f"Search radius: {RADIUS_METERS} m; HTTP status: {status}")
    print(f"OSM elements returned: {len(elements)}")
    for category, count in sorted(summary.items()):
        print(f"  {category}: {count}")
    print(f"Raw response and query saved to {output_path}")
    print("Counts are not final: they depend on the unverified search centre and OSM mapping coverage.")


if __name__ == "__main__":
    main()
