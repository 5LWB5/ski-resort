"""Fetch one named OpenStreetMap/Nominatim result as a coordinate candidate.

This pilot deliberately collects only one resort. Review the returned OSM
object and its centre before treating its coordinates as the ski area location.
"""

from __future__ import annotations

import argparse
import csv
import json
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urlencode
from urllib.request import Request, urlopen


PROJECT_DIR = Path(__file__).resolve().parents[1]
ROSTER_PATH = PROJECT_DIR / "data" / "reference" / "resort_roster.csv"
OUTPUT_DIR = PROJECT_DIR / "data" / "raw" / "coordinate_candidates"
USER_AGENT = "TravelDesignerResortRanking/0.1 (research prototype)"


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("resort_id", help="ID from data/reference/resort_roster.csv")
    args = parser.parse_args()

    with ROSTER_PATH.open("r", encoding="utf-8-sig", newline="") as stream:
        resorts = list(csv.DictReader(stream))
    matches = [row for row in resorts if row["resort_id"] == args.resort_id]
    if len(matches) != 1:
        raise SystemExit(f"Expected one roster row for {args.resort_id}, found {len(matches)}")
    resort = matches[0]

    params = {
        "q": f"{resort['name_ru']}, {resort['region_from_brief']}, Россия",
        "format": "jsonv2",
        "addressdetails": "1",
        "extratags": "1",
        "limit": "5",
        "accept-language": "ru",
    }
    request_url = "https://nominatim.openstreetmap.org/search?" + urlencode(params)
    request = Request(request_url, headers={"User-Agent": USER_AGENT})
    with urlopen(request, timeout=30) as response:
        status = response.status
        results = json.load(response)

    payload = {
        "source": "OpenStreetMap Nominatim Search API",
        "resort_id": resort["resort_id"],
        "roster_name": resort["name_ru"],
        "roster_region": resort["region_from_brief"],
        "retrieved_at_utc": datetime.now(timezone.utc).isoformat(),
        "request_url": request_url,
        "http_status": status,
        "results": results,
        "review_status": "candidate_only_not_yet_verified",
    }

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    output_path = OUTPUT_DIR / f"{resort['resort_id']}_nominatim_candidates.json"
    output_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")

    print(f"Resort: {resort['name_ru']} ({resort['resort_id']})")
    print(f"HTTP status: {status}; candidates: {len(results)}")
    for index, result in enumerate(results, start=1):
        print(
            f"{index}. {result.get('display_name')} | "
            f"type={result.get('type')} | lat={result.get('lat')} | lon={result.get('lon')}"
        )
    print(f"Raw API response saved to {output_path}")
    print("These are candidates; verify the mapped feature before using its coordinates.")


if __name__ == "__main__":
    main()
