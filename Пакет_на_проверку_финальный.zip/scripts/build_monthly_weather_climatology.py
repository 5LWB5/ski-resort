"""Build a monthly historical weather baseline for active resorts.

Fetches daily ERA5 reanalysis from Open-Meteo Historical Weather API for the
complete years 2016-2025, keeps each raw response, then writes one summary row
per resort and calendar month. This is a historical estimate, not a forecast.
"""
from __future__ import annotations

import argparse
import csv
import json
import statistics
import time
from datetime import datetime, timezone
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.parse import urlencode
from urllib.request import Request, urlopen


PROJECT_DIR = Path(__file__).resolve().parents[1]
RESORTS_PATH = PROJECT_DIR / "data" / "reference" / "resort_data_collection_template.csv"
RAW_ROOT = PROJECT_DIR / "data" / "raw" / "historical_weather"
PROCESSED_DIR = PROJECT_DIR / "data" / "processed"
ENDPOINT = "https://archive-api.open-meteo.com/v1/archive"
USER_AGENT = "TravelDesignerResortRanking/0.1 (prototype)"
START_DATE = "2016-01-01"
END_DATE = "2025-12-31"
DAILY_VARIABLES = [
    "temperature_2m_mean",
    "temperature_2m_max",
    "temperature_2m_min",
    "snowfall_sum",
    "precipitation_sum",
    "wind_speed_10m_max",
]
MONTHS_RU = [
    "январь", "февраль", "март", "апрель", "май", "июнь",
    "июль", "август", "сентябрь", "октябрь", "ноябрь", "декабрь",
]


def fetch_json(url: str) -> tuple[int, dict]:
    request = Request(url, headers={"User-Agent": USER_AGENT})
    with urlopen(request, timeout=120) as response:
        return response.status, json.load(response)


def avg(values: list[float]) -> float | None:
    return round(statistics.fmean(values), 2) if values else None


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--start-date", default=START_DATE)
    parser.add_argument("--end-date", default=END_DATE)
    parser.add_argument("--pause-seconds", type=float, default=5.0,
                        help="Pause between location requests (default: 5 seconds).")
    parser.add_argument("--resume-dir", help="Reuse successful raw responses from an existing run folder.")
    args = parser.parse_args()

    with RESORTS_PATH.open(encoding="utf-8-sig", newline="") as stream:
        resorts = [row for row in csv.DictReader(stream)
                   if row.get("project_status", "active") == "active"]
    missing = [row["resort_name"] for row in resorts
               if not row.get("latitude") or not row.get("longitude")]
    if missing:
        raise SystemExit("Active resorts are missing coordinates: " + ", ".join(missing))
    if not resorts:
        raise SystemExit("No active resorts found in the coordinate table.")

    run_time = datetime.now(timezone.utc)
    period_tag = f"{args.start_date.replace('-', '')}_{args.end_date.replace('-', '')}"
    if args.resume_dir:
        raw_dir = Path(args.resume_dir)
        if not raw_dir.is_absolute():
            raw_dir = PROJECT_DIR / raw_dir
        if not raw_dir.is_dir():
            raise SystemExit(f"Resume folder not found: {raw_dir}")
        run_stamp = raw_dir.name.split("_")[-1]
    else:
        run_stamp = run_time.strftime("%Y%m%dT%H%M%SZ")
        raw_dir = RAW_ROOT / f"{period_tag}_{run_stamp}"
    raw_dir.mkdir(parents=True, exist_ok=True)
    PROCESSED_DIR.mkdir(parents=True, exist_ok=True)

    monthly_rows: list[dict] = []
    failures: list[str] = []
    for resort_index, resort in enumerate(resorts):
        params = {
            "latitude": resort["latitude"],
            "longitude": resort["longitude"],
            "start_date": args.start_date,
            "end_date": args.end_date,
            "daily": ",".join(DAILY_VARIABLES),
            "timezone": "auto",
            "temperature_unit": "celsius",
            "wind_speed_unit": "kmh",
            "precipitation_unit": "mm",
            "models": "era5",
        }
        url = ENDPOINT + "?" + urlencode(params)
        raw_file = raw_dir / f"{resort['resort_id']}.json"
        retrieved_at = datetime.now(timezone.utc).isoformat()
        payload: dict
        status = 0
        response: dict = {}
        error_text = ""
        did_request = False
        if raw_file.exists():
            try:
                existing = json.loads(raw_file.read_text(encoding="utf-8"))
                existing_response = existing.get("response", {})
                if existing_response.get("daily", {}).get("time"):
                    response = existing_response
                    status = int(existing.get("http_status", 200))
                    retrieved_at = existing.get("retrieved_at_utc", retrieved_at)
                    print(f"{resort['resort_id']} {resort['resort_name']}: reusing saved response")
            except (OSError, json.JSONDecodeError, AttributeError, TypeError):
                pass
        if not response:
            did_request = True
            for attempt in range(1, 4):
                try:
                    status, response = fetch_json(url)
                    error_text = ""
                    break
                except (HTTPError, URLError, TimeoutError) as exc:
                    error_text = str(exc)
                    if attempt < 3:
                        time.sleep(attempt * 5)
        if error_text:
            payload = {
                "source": "Open-Meteo Historical Weather API",
                "resort_id": resort["resort_id"], "resort_name": resort["resort_name"],
                "retrieved_at_utc": retrieved_at, "request_url": url,
                "http_status": status, "error": error_text, "response": response,
            }
            raw_file.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
            failures.append(f"{resort['resort_id']} {resort['resort_name']}: {error_text}")
            print(f"{resort['resort_id']} {resort['resort_name']}: FAILED ({error_text})")
        else:
            payload = {
                "source": "Open-Meteo Historical Weather API",
                "resort_id": resort["resort_id"], "resort_name": resort["resort_name"],
                "input_coordinates": {"latitude": resort["latitude"], "longitude": resort["longitude"]},
                "period": {"start_date": args.start_date, "end_date": args.end_date},
                "model": "ERA5", "daily_variables": DAILY_VARIABLES,
                "retrieved_at_utc": retrieved_at, "request_url": url,
                "http_status": status, "response": response,
            }
            raw_file.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")

            daily = response.get("daily", {})
            dates = daily.get("time", [])
            per_year_month: dict[tuple[int, int], dict[str, list[float]]] = {}
            for day_index, day_string in enumerate(dates):
                day = datetime.strptime(day_string, "%Y-%m-%d")
                key = (day.year, day.month)
                metrics = per_year_month.setdefault(key, {name: [] for name in DAILY_VARIABLES})
                for name in DAILY_VARIABLES:
                    values = daily.get(name, [])
                    value = values[day_index] if day_index < len(values) else None
                    if value is not None:
                        metrics[name].append(float(value))

            for month in range(1, 13):
                yearly: dict[str, list[float]] = {name: [] for name in DAILY_VARIABLES}
                snowy_days_per_year: list[float] = []
                for (year, year_month), metrics in per_year_month.items():
                    if year_month != month:
                        continue
                    for name in ("temperature_2m_mean", "temperature_2m_max", "temperature_2m_min",
                                 "wind_speed_10m_max"):
                        value = avg(metrics[name])
                        if value is not None:
                            yearly[name].append(value)
                    for name in ("snowfall_sum", "precipitation_sum"):
                        if metrics[name]:
                            yearly[name].append(round(sum(metrics[name]), 2))
                    snowy_days_per_year.append(float(sum(v > 0.1 for v in metrics["snowfall_sum"])))

                snow_years = yearly["snowfall_sum"]
                monthly_rows.append({
                    "resort_id": resort["resort_id"], "resort_name": resort["resort_name"],
                    "latitude_input": resort["latitude"], "longitude_input": resort["longitude"],
                    "latitude_api_grid": response.get("latitude"),
                    "longitude_api_grid": response.get("longitude"),
                    "elevation_api_m": response.get("elevation"), "timezone": response.get("timezone"),
                    "month_number": month, "month_name_ru": MONTHS_RU[month - 1],
                    "period_start": args.start_date, "period_end": args.end_date,
                    "years_included": len(yearly["temperature_2m_mean"]),
                    "mean_daily_mean_temp_c": avg(yearly["temperature_2m_mean"]),
                    "mean_daily_max_temp_c": avg(yearly["temperature_2m_max"]),
                    "mean_daily_min_temp_c": avg(yearly["temperature_2m_min"]),
                    "mean_monthly_snowfall_cm": avg(snow_years),
                    "median_monthly_snowfall_cm": round(statistics.median(snow_years), 2) if snow_years else None,
                    "mean_monthly_precipitation_mm": avg(yearly["precipitation_sum"]),
                    "mean_daily_max_wind_kmh": avg(yearly["wind_speed_10m_max"]),
                    "mean_snowy_days_per_month": avg(snowy_days_per_year),
                    "model": "ERA5", "source": "Open-Meteo Historical Weather API",
                    "generated_at_utc": run_time.isoformat(),
                    "raw_response_file": str(raw_file.relative_to(PROJECT_DIR)),
                    "status": "ok",
                })
            print(f"{resort['resort_id']} {resort['resort_name']}: saved {len(dates)} daily records")

        if did_request and resort_index < len(resorts) - 1:
            time.sleep(max(0.0, args.pause_seconds))

    fields = [
        "resort_id", "resort_name", "latitude_input", "longitude_input",
        "latitude_api_grid", "longitude_api_grid", "elevation_api_m", "timezone",
        "month_number", "month_name_ru", "period_start", "period_end", "years_included",
        "mean_daily_mean_temp_c", "mean_daily_max_temp_c", "mean_daily_min_temp_c",
        "mean_monthly_snowfall_cm", "median_monthly_snowfall_cm",
        "mean_monthly_precipitation_mm", "mean_daily_max_wind_kmh",
        "mean_snowy_days_per_month", "model", "source", "generated_at_utc",
        "raw_response_file", "status",
    ]
    output_tag = "weather_monthly_climatology" if not failures else "weather_monthly_climatology_incomplete"
    final_path = PROCESSED_DIR / f"{output_tag}_{period_tag}_{run_stamp}.csv"
    output_paths = [final_path]
    latest_path = PROCESSED_DIR / "weather_monthly_climatology.csv"
    if not failures:
        output_paths.append(latest_path)
    for output_path in output_paths:
        with output_path.open("w", encoding="utf-8-sig", newline="") as stream:
            writer = csv.DictWriter(stream, fieldnames=fields)
            writer.writeheader()
            writer.writerows(monthly_rows)

    print(f"Monthly rows written: {len(monthly_rows)} (expected {len(resorts) * 12})")
    print(f"Versioned output: {final_path}")
    if not failures:
        print(f"Latest output: {latest_path}")
    print(f"Raw responses: {raw_dir}")
    if failures:
        print(f"Failed resorts: {len(failures)}; check raw error files in {raw_dir}")
        for failure in failures:
            print(f"  {failure}")


if __name__ == "__main__":
    main()
